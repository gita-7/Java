package CustomException;

public class MyException extends Exception{
    public MyException(String errorMessage)
    {
        super(errorMessage);
    }
}

class Voting{
    void validateAge(int Age) throws MyException{
        if(Age < 18)
        {
            throw new MyException("You can't vote");
        }
        else
            System.out.println("You can vote");
    }

    public static void main(String[] args) {
        try {
            Voting obj = new Voting();
            obj.validateAge(18);
        }
        catch (MyException e)
        {
            System.out.println("caught error:" +e.getMessage());
        }
    }
}
