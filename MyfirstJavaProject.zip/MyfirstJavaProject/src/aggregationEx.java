class AggregationEx {
    int square(int side)
    {
        return side*side;
    }
}

class Circle {
    AggregationEx ag;
    double pi = 3.45;

    double area(int radius) {
        ag = new AggregationEx();
        int rsquare = ag.square(radius);
        return pi * rsquare;
    }

    public static void main(String args[]) {
        Circle c = new Circle();
        double result = c.area(5);
        System.out.println(result );
    }
}