package multipleInheritance;

public class Car implements Travel, Vehicle{
    @Override
    public void run()
{
        System.out.println("car runs.");
        // Resolving the conflict explicitly
        Vehicle.super.run();
    }

    public static void main(String[] args) {
        Car obj = new Car();
        obj.run();
    }
}
