package multipleInheritance;

interface Travel {
   default void run(){}
}
interface Vehicle{
    default void run() {
    }
}
