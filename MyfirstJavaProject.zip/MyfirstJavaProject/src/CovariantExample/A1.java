package CovariantExample;

class A1
{
     A1 func()
     {
         return this;
     }
     void print() {
         System.out.println("inside the class A1");
     }
}
class A2 extends A1
{
    @Override
    A2 func() {return this;}
    void print() {
        System.out.println("inside the class A2");
    }
}
class A3 extends A1
{
    @Override
    A3 func() {return this;}
    @Override
    void print() {
        System.out.println("inside the class A3");
    }
}
class Test{
    public static void main(String[] args)
    {
        A1 a1 = new A1();
        a1.func().print();
        A2 a2 = new A2();
        a2.func().print();
        A3 a3 = new A3();
        a3.print();
    }
}

