package model;

public class Furniture {
    private String name;
    private String color;

    public Furniture() {
        System.out.println("Furniture created !!!");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Furniture{" +
                "name='" + name + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
