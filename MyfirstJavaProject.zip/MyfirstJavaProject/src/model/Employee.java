package model;

import java.util.Objects;

public class Employee implements Comparable<Employee> {
    private String name;
    private int id;
    private String emailId;

    public Employee() {
        System.out.println("Default constructor");
    }

    public Employee(String name, int id, String emailId) {
        this.name = name;
        this.id = id;
        this.emailId = emailId;
    }

    public Employee(String name) {
        this.name = name;
    }

    public Employee(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public int compareTo(Employee o) {
        return Integer.compare(this.getId(), o.getId());
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", emailId='" + emailId + '\'' +
                '}';
    }

/*
    @Override
    public boolean equals(Object anObject) {
        if (this == anObject) {
            return true;
        }
        if (anObject instanceof Employee) {
            Employee employee = (Employee)anObject;
            return this.getEmailId().equals(employee.getEmailId()) &&
                    this.getName().equals(employee.getName()) && this.getId() == employee.getId();
        }
        return false;
    }
*/

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id && name.equals(employee.name) && emailId.equals(employee.emailId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, id, emailId);
    }
}
