package model;

public class Car extends Vehicle {
    private String carName;

}
