package model;

public class Home {
    private Furniture furniture;

    Home() {
        System.out.println("Home created !!!");
    }

    public Furniture getFurniture() {
        return furniture;
    }

    public void setFurniture(Furniture furniture) {
        System.out.println("Set furniture called !!!");
        this.furniture = furniture;
    }

    @Override
    public String toString() {
        return "Home{" +
                "furniture=" + furniture +
                '}';
    }
}
