package DataStructure;

class ArrayProblems
{
    /*String substringFinder(String input1, String input2)
    {
        char arr1[] = input1.toCharArray();
        char arr2[] = input2.toCharArray();
        List<Character> list = new ArrayList<>();
        String str;

        for(int i=0; i<input1.length(); i++)
        {
            for(int j=0; j<input2.length(); j++)
            {
                if(arr1[i] == arr2[j] && !list.contains(arr1[i]))
                {
                    list.add(arr1[i]);
                }
            }
        }
        System.out.println(list.toString());
        return list.toString();
    }*/

    public int[] twoSum(int[] nums, int target)
    {
        int arr[] = {};
        for (int i = 0; i < nums.length; i++)
        {
            for (int j = i + 1; j < nums.length; j++)
            {
                if (nums[i] == target)
                {
                    arr[i] = i;
                    return arr;
                }
                if (nums[i] + nums[j] == target)
                {
                    arr[i] = j;
                    return arr;
                }
            }
        }
        return arr;
    }

    public int romanToInt(String s) {

        char[] arr = s.toCharArray();
        int res = 0;
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            switch (arr[i]) {
                case 'I':
                    res = 1;
                    break;
                case 'V':
                    res = 5;
                    break;
                case 'X':
                    res = 10;
                    break;
                case 'L':
                    res = 50;
                    break;
                case 'C':
                    res = 100;
                    break;
                case 'D':
                    res = 500;
                    break;
                case 'M':
                    res = 1000;
                    break;
                default:
                    System.out.println("invalid input");
            }
            if (i < arr.length - 1 && res < getValue(arr[i + 1])) {
                sum = sum - res;
            } else {
                sum = sum + res;
            }
        }
        return sum;
    }
        int getValue(char ch)
        {
            switch (ch)
            {
                case 'I':
                    return 1;
                case 'V':
                    return 5;
                case 'X':
                    return 10;
                case 'L':
                    return 50;
                case 'C':
                    return 100;
                case 'D':
                    return 500;
                case 'M':
                    return 1000;
                default:
                    return 0;
            }
        }

    public String longestCommonPrefix(String[] strs)
    {
        if (strs == null || strs.length == 0)
        {
            return "";
        }
        return "";
    }
        public static void main (String[]args)
        {
            ArrayProblems obj = new ArrayProblems();
            //obj.substringFinder("I am the tallest", "Imtl");
            //obj.twoSum(new int[]{2, 7, 11, 15}, 11);
            System.out.println(obj.romanToInt("MCMXCIV"));
        }
}

