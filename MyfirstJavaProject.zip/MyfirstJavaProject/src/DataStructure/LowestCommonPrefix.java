package DataStructure;

import javafx.util.Pair;

import java.util.ArrayList;
import java.util.List;

public class LowestCommonPrefix {
    public String LCP(String[] str) {
        if (str.length == 0 && str == null) {
            return "";
        }
        int minLen = Integer.MAX_VALUE;
        for (int idx = 0; idx < str.length; idx++) {
            minLen = Math.min(minLen, str[idx].length());
        }
        String LCP = "";

        boolean stopProcessing = false;
        for (int idx = 0; idx < minLen; idx++) {
            //iterate all strings
            Character ch = null;
            for (String eachStr : str) //for(int i=0; i<str.length; i++)
            {
                if (ch == null) {
                    ch = eachStr.charAt(idx);
                } else
                {
                    if (ch != eachStr.charAt(idx))
                    {
                        stopProcessing = true;
                        break;
                    }
                }
            }
            if (stopProcessing == true) {
                return str[0].substring(0, idx);
            }
            //at exit of loop update LCP
        }
        return str[0].substring(0, minLen);
    }

    public String reverseWord(String str) {
        // Reverse the string str
        char[] charr = str.toCharArray();
        String reverse = "";
        for(int i = charr.length-1; i>=0; i--)
        {
            reverse = reverse + str.charAt(i);
        }
        return reverse;
    }

    public Pair<Long, Long> getMinMax(int[] arr) {
        // Code Here
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for(int i=0; i<arr.length; i++)
        {
            min = Math.min(min, arr[i]);
            max = Math.max(max, arr[i]);
        }
        return new Pair(min, max);
    }

    public int kthSmallest(int[] arr, int k) {
        // Your code here
        int kthSmallest = 0;
        for(int i=0; i<arr.length; i++)
        {
            for(int j=i+1; j<arr.length; j++)
            {
                if(arr[i] > arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }

        return arr[k-1];
    }

    /*public static void merge(int arr[], int l, int m, int r)
    {
        // Find sizes of two subarrays to be merged
        int n1 = m - l + 1;
        int n2 = r - m;

        // Create temp arrays
        int L[] = new int[n1];
        int R[] = new int[n2];

        // Copy data to temp arrays
        for (int i = 0; i < n1; ++i)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[m + 1 + j];

        // Merge the temp arrays

        // Initial indices of first and second subarrays
        int i = 0, j = 0;

        // Initial index of merged subarray array
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            }
            else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements of L[] if any
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        // Copy remaining elements of R[] if any
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }*/
    // Main function that sorts arr[l..r] using
    // merge()
    /*public static void sort(int arr[], int l, int r)
    {
        if (l < r) {

            // Find the middle point
            int m = (l + r) / 2;

            // Sort first and second halves
            sort(arr, l, m);
            sort(arr, m + 1, r);

            // Merge the sorted halves
            merge(arr, l, m, r);
        }
    }*/

    public static void printArray(int arr[])
    {
        for (int i = 0; i < arr.length; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

    public int[] segregateElements(int[] arr) {
        // Your code goes here
        for(int i=0; i<arr.length; i++)
        {
            if(arr[i]<0)
            {
                arr[arr.length-i] = arr[i];
            }
        }
        return arr;
    }

    public int doUnion(int arr1[], int arr2[]) {
        int n1 = arr1.length;
        int n2 = arr2.length;

        List<Integer> list = new ArrayList<>();

        for (int i = 0; i < n1; i++) {
             list.add(arr1[i]);
        }
        for (int i = 0; i < n2; i++) {
            list.add(arr2[i]);
        }

        int[] arr = new int[list.size()];

        for (int i = 0; i < list.size(); i++) {
            arr[i] = list.get(i);
        }

        //sort the array
        int p=0, r=arr.length-1;
        sort(arr, p, r);

        List<Integer> newlist = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] != arr[i + 1]) {
                newlist.add(arr[i]);
            }
        }
        newlist.add(arr[arr.length - 1]);
        return newlist.size();
    }

    int getMinDiff(int[] arr, int k) {
        int n = arr.length;
        sort(arr, 0, arr.length-1);
        int res = arr[n - 1] - arr[0];

        // For all indices i, increment arr[0...i-1] by k and
        // decrement arr[i...n-1] by k
        for (int i = 1; i < arr.length; i++) {

            // Impossible to decrement height of ith tower by k,
            // continue to the next tower
            if (arr[i] - k < 0)
                continue;

            // Minimum height after modification
            int minH = Math.min(arr[0] + k, arr[i] - k);

            // Maximum height after modification
            int maxH = Math.max(arr[i - 1] + k, arr[n - 1] - k);

            // Store the minimum difference as result
            res = Math.min(res, maxH - minH);
        }
        return res;
    }

    public void sort(int arr[], int p, int r)
    {
        if(p<r)
        {
            int q = (p+r)/2;
            sort(arr, p, q);
            sort(arr, q+1, r);
            merge(arr, p, q, r);
        }
    }

    public void merge(int arr[], int p, int q, int r)
    {
        int n1 = q-p+1;
        int n2 = r-q;
        int L[] = new int[n1];
        int R[] = new int[n2];
        //copy array
        for(int i=0; i<n1; i++)
        {
            L[i] = arr[p+i];
        }
        for(int i=0; i<n2; i++)
        {
            R[i] = arr[q+1+i];
        }
        //merge 2 arrays
        int i=0, j=0, k=p;
        while(i<n1 && j<n2)
        {
            if(L[i] <= R[j])
            {
                arr[k] = L[i];
                i++;
            }
            else
            {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while(i<n1)
        {
            arr[k] = L[i];
            i++;
            k++;
        }
        while(j<n2)
        {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    public int recursionFactorial(int num)
    {
        while (num > 0)
        {
            return  num * recursionFactorial(num-1);
        }
        return 1;
    }

    public int binarySearch(int arr[], int num)
    {
        int low = 0;
        int high = arr.length-1;

        while(low<=high)
        {
            int mid = (low + high)/2;
            if(arr[mid] == num)
            {
                return mid;
            }
            else if(num < arr[mid])
            {
                high = mid-1;
            }
            else
            {
                low = mid+1;
            }
        }
        return -1;
    }


    //given input is palindrome or not without recursion
    public boolean checkPalindrome(String str)
    {
        String reverseWord = getReverse(str);
        if (str.equals(reverseWord))
        {
            return true;
        }
        return false;
    }

    //palindrome using recursion getReverse method -->
    public static boolean isPalindrome2(String str, int start, int end)
    {

         return isPalindrome2(str, start+1, end-1);
    }

    //fibonacci using recursion
    public void fibonacci(int num, int first, int sec)
    {
        while (num > 0)
        {
             fibonacci(--num, sec, first+sec);
        }
        return;
    }

    public boolean isAnagram(String str1, String str2)
    {
        if(str1 == null && str2 == null || str1.isEmpty() && str2.isEmpty())
        {
            return true;
        }
        arraySort(str1);
        arraySort(str2);
        if(str1.equals(str2)){
            return true;
        }
        return false;
    }

    public boolean frequency(String str)
    {
        char ch[] = str.toCharArray();
        char temp[] = new char[ch.length];
        int count = 0;
        for(int i=0; i<ch.length; i++)
        {
            for(int j=i+1; j<ch.length; j++)
            {
                if(ch[i] == ch[j] && ch[i] != temp[i])
                {
                    temp[i] = ch[i];
                    System.out.println(ch[i] + " " + count++);
                }
                else
                {
                    System.out.println(ch[i] + " " + count++);
                }
            }
            count = 0;
        }
        return false;
    }

    public String arraySort(String str1)
    {
       // HashMap<String, Integer> hashMap = new HashMap<>();
        char[] ch = str1.toCharArray();
        for(int i=0; i<str1.length(); i++)
        {
            for(int j=i+1; j<str1.length(); j++) {
                if (ch[j] <= ch[i])
                {
                    char temp = ch[i];
                    ch[i] = ch[j];
                    ch[j] = temp;
                }
            }
        }
        return new String(ch);
    }
    public static String getReverse(String str)
    {
        char[] ch = str.toCharArray();
        String reverseWord = "";
        for(int i = ch.length-1; i>=0; i--)
        {
             reverseWord = reverseWord + str.charAt(i);
        }
        return reverseWord;
    }

    public static void main(String[] args) {
        LowestCommonPrefix lcp = new LowestCommonPrefix();
        //System.out.println(lcp.LCP(new String [] {"flower","flow","flight"}));
        //System.out.println(lcp.reverseWord("Geeks"));
        //System.out.println(lcp.getMinMax(new int [] {28078, 19451, 935, 28892, 2242, 3570, 5480, 231}));
        //System.out.println(lcp.kthSmallest(new int[] {7, 10, 4, 3, 20, 15}, 3));
        //int arr[] = { 12, 11, 13, 5, 6, 7, 15, 1, 10, 2 };
        //int arr[] = {1, -1, 3, 2, -7, -5, 11, 6};
        //int arr[] = {1, 8, 10, 6, 4, 6, 9, 1};

        /*System.out.println("Given array is");
        printArray(arr);

        sort(arr, 0, arr.length - 1);

        System.out.println("\nSorted array is");
        printArray(arr);*/

        //lcp.segregateElements(arr);
        //int arr1[] = {1,2,3,4,5};
        //int arr2[] = {1,2,3};
        //int bArr[] = {1,2,3,4,5,6,7,8,9,10};

        //System.out.println(lcp.doUnion(arr1, arr2));
        //System.out.println(lcp.getMinDiff(arr, 7));
        //System.out.println(lcp.recursionFactorial(5));
        //System.out.println(lcp.binarySearch(bArr, 10));
        //printArray(arr); //1 3 2 11 6 -1 -7 -5

        //Scanner sc = new Scanner(System.in);
        //String InputWord = sc.nextLine();
        //System.out.println(lcp.checkPalindrome(InputWord));
        //System.out.println(lcp.fibonacci(10, 0, 1));
        //System.out.println(lcp.arraySort("apple"));
        System.out.println(lcp.frequency("It is java language"));
    }
}
