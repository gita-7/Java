package spring;

import model.Home;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAutowire {

    public static void main(String[] args) {
        TestAutowire testAutowire = new TestAutowire();
        testAutowire.testAutowireByName();
    }

    private void testAutowireByName() {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContextV2.xml");
        Home home = (Home)applicationContext.getBean("home");
        System.out.println(home);
    }
}
