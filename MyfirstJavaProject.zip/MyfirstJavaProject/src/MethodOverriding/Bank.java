package MethodOverriding;

class Bank {
    int getRateofInterest()
    {
        return 0;
    }
}
class SBI extends Bank{
    int getRateofInterest()
    {
        return 4;
    }
}
class ICICI extends Bank{
    int getRateofInterest()
    {
        return 5;
    }
}
class Axis extends Bank{
    int getRateofInterest() {
        return 6;
    }
}

class Test{
    public static void main(String[] args) {
        SBI s = new SBI();
        ICICI i = new ICICI();
        Axis a = new Axis();
        System.out.println("SBI Interest rate : " + s.getRateofInterest());
        System.out.println("ICICI Interest rate : " + i.getRateofInterest());
        System.out.println("Axis Interest rate : " + a.getRateofInterest());
    }
}
