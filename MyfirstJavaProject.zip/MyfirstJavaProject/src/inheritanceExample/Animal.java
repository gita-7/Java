package inheritanceExample;

public class Animal {
    void sound()
    {
        System.out.println("animal barks");
    }
}


