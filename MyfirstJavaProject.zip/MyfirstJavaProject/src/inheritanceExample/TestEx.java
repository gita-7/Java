package inheritanceExample;

public class TestEx {
    public static void main(String[] args) {
        Animal a = new Dog();
        Dog d = new Dog();
        a.sound();
        d.walks();
    }
}
