package inheritanceExample;

public class Dog extends Animal {
    void sound()
    {
        System.out.println("Dog barks");
    }
    void walks()
    {
        System.out.println("Dog walks");
    }
}
