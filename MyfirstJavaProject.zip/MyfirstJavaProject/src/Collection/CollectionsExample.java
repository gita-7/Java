package Collection;

import model.Employee;

import java.util.*;

public class CollectionsExample {
    public static void main(String[] args) {
        //stestSorting();
        testEqualsAndHashCode();
    }

    public static void testSorting() {
        List<Employee> list = new ArrayList<>();
        Integer num = new Integer(100);
        list.add(new Employee("Ankit", 94123, "rnkit@gmail.com"));
        list.add(new Employee("Aman", 123489, "aman@gmail.com"));
        list.add(new Employee("Chahit", 2356, "chahit93@gmail.com"));

        List<Employee> list2 = new ArrayList<>();
        list2.addAll(list);

        List<Employee> list3 = new ArrayList<>();
        list3.addAll(list);

        Comparator<Employee> comparatorForName = new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getName().compareTo(o2.getName());
            }
        };

        Comparator<Employee> comparatorForEmailId = new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getEmailId().compareTo(o2.getEmailId());
            }
        };

        Collections.sort(list);
        Collections.sort(list2, comparatorForName);
        Collections.sort(list3, comparatorForEmailId);

        System.out.println("list:" + list);
        System.out.println("list2:" + list2);
        System.out.println("list3:" + list3);

        Map<String, Integer> treeMap = new TreeMap<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return 0;
            }
        });
        treeMap.put("apple", 200);
        treeMap.put("appe", 100);
        treeMap.put("banana", 9);

        System.out.println("TreeMap:" + treeMap);



    }

    public static void testEqualsAndHashCode() {
        String str = "apple";
        String newStr = new String("apple");

        System.out.println(str == newStr);
        System.out.println(str.equals(newStr));

        Employee employee = new Employee("Ankit", 94123, "rnkit@gmail.com");
        Employee employee1 = new Employee("Ankit", 94123, "rnkit@gmail.com");
/*
        System.out.println(employee.hashCode());
        System.out.println(employee1.hashCode());*/
        System.out.println(employee == employee1);
        System.out.println(employee.equals(employee1));

        // NOTE : when you change equals then change hashcode also.


    }
}
