package Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CollectionHierarchy {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("computer");
        list.add("keyboard");
        list.add("mouse");
        list.add("joystick");
        list.add("PS5");

        Iterator<String> iterator = list.listIterator();
        while (iterator.hasNext())
        {
            System.out.println(iterator.next());
        }
        for(String l : list)
        {
            System.out.println(l);
        }
    }

}
