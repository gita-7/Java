package InstanceofEx;

class Animal {
    void method()
    {
        System.out.println("parent class method invoked");
    }
}
class Dog extends Animal
{
    static void method(Animal a)
    {
        if(a instanceof Dog)
        {
            Dog d = (Dog) a; //downcasting
        }
        System.out.println("child class method invoked");
    }

    public static void main(String[] args) {
        Animal a = new Dog();
        Dog.method(a);
    }
}
