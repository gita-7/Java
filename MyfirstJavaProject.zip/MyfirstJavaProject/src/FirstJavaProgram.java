public class FirstJavaProgram {

    private Integer value;
    private static Integer constValue = 0;

    public FirstJavaProgram(Integer value) {
        this.value = value;
    }

    public static void main(String[] args) {
        System.out.println("Namaste Java");
        FirstJavaProgram object = new FirstJavaProgram(10);
        object.printInstanceValue(); // 10
        FirstJavaProgram.incrementStaticValue(); // 1
        object.printStaticValue(); // 1

        FirstJavaProgram object2 = new FirstJavaProgram(20);
        object2.printInstanceValue(); // 20
        object2.printStaticValue(); // 1
        FirstJavaProgram.incrementStaticValue(); // 2
        object2.printStaticValue(); // 2
    }

    public void printInstanceValue() {
        System.out.println("Instance Value: " + value);
    }

    public void printStaticValue() {
        System.out.println("Class Value: " + constValue);
    }

    public void testMethod() {
        System.out.println("Class Value: " + value);
    }

    public static void incrementStaticValue() {
        constValue ++;
    }

}
