import model.Employee;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestUsingCI
{
    public static void main(String[] args) {
        testUsingConstructor();
        testUsingConstructor2();
        testUsingConstructor3();
    }

    public static void testUsingConstructor()
    {
        Resource r = new ClassPathResource("applicationContextV2.xml");
        BeanFactory bf = new XmlBeanFactory(r);

        Employee emp = (Employee)bf.getBean("emp1");
        System.out.println(emp.getId());
    }

    public static void testUsingConstructor2()
    {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContextV2.xml");
        Employee emp = (Employee)applicationContext.getBean("emp2");
        System.out.println(emp.getName());
    }

    public static void testUsingConstructor3()
    {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContextV2.xml");
        Employee emp = (Employee)applicationContext.getBean("emp3");
        System.out.println(emp.getName());
        System.out.println(emp.getId());
    }
}
