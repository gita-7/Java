package com.gameRunner.springBootGameRunnerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGameRunnerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
